// sol.hpp
// Sol header files for C++
// <<extern "C">> not supplied automatically because Sol also compiles as C++

extern "C" {
#include "sol.h"
#include "sollib.h"
#include "lauxlib.h"
}
